create
    definer = root@`%` procedure GenerateLoveQuotes()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 10000 DO
            INSERT INTO love_quotes (quote, category, sentiment, emotion, author)
            VALUES
                ('这是一条示例情话，实际内容应更丰富和多样。', '浪漫', '积极', '幸福', '匿名')
                -- 可以根据需要增加更多样例，或使用循环生成随机内容

            ;
            SET i = i + 1;
        END WHILE;
END;

